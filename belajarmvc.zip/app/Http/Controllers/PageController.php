<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
// use App\Models\ModelMahasiswa;
use App\Models\ModelKaryawan;

class PageController extends Controller
{
    
    public function about(){
        $navtitle = array(
            "home" => "Beranda",
            "about" => "Tentang"
        );
        return view('about')->with();
    }
    // public function get_mahasiswa(Request $request){
    //     $data = ModelMahasiswa::all();
    //     // return json_encode($data);
    //     return view('obtain_mhs')->with('data', json_encode($data));
    // }
    public function insert_karyawan(Request $request){
        $data = new ModelKaryawan();
        $data->nip = $request->input('nip');
        $data->nm_lengkap = $request->input('nm_lengkap');
        $data->tempat_lahir = $request->input('tempat_lahir');
        $data->tgl_lahir = $request->input('tgl_lahir');
        $data->alamat = $request->input('alamat');
        $data->jk = $request->input('jk');
        $data->no_telp = $request->input('no_telp');
        $data->gaji = $request->input('gaji');
        $data->status = $request->input('status');
        
        if($data->save()){
            return response()->json([
                'pesan' => 'Data berhasil dibuat!'
            ]);
        }
        else{
            return response()->json([
                'pesan' => 'Galat, data gagal dibuat!'
            ]);
        }


    }
}
