<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('bs5/css/bootstrap.css')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> - Web Programming GunaharWisers</title>
</head>
<body>
<?php echo $__env->make('layouts/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('main_section'); ?>
</body>
</html><?php /**PATH C:\laragon\www\belajarmvc\resources\views/layouts/main.blade.php ENDPATH**/ ?>