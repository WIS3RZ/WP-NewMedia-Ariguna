<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class SeederMahasiswa extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('tb_mahasiswa')->insert([
            'nm_lengkap' => 'José Maria Massimiliani Quesada',
            'nm_user' => 'pepemassimilianiq',
            'tempat_lahir' => 'Monterrey, Nuevo León, Meksiko',
            'tgl_lahir' => Carbon::create(1990, 6, 21)->toDateTimeString(),
            'alamat' => "Mazatlán, Sinaloa, Meksiko",
            'jk' => 'L',
            'jns_kelas' => 'Malam',
            'prg_studi' => 'Web Programming dan Mobile Apps'
        ]);
    }
}
