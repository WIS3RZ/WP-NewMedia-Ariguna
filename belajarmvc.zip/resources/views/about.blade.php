@extends('layouts/main')

@section('title', $navtitle)