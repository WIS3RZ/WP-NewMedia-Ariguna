@extends('layouts/main')
@section('main_section')
{{ $data }}
@endsection